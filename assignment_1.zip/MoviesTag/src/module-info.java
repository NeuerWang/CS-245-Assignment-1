module MoviesTag {
	requires opencsv;
}
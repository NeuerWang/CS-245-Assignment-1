package main;

public class Movie extends Count {

	public Movie(String tag) {
		super(tag);
		
	}
	
	@Override
	public String toString() {
		return "Movie [ID=" + getTag() + ", count=" + getCount() + "]";
	}

}

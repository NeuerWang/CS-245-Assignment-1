package main;

class Tag extends Count {

	public Tag(String tag) {
		super(tag);
		
	}

	// @Override
    // public int compareTo(Count other) {
    //         return Integer.compare(this.getCount(), other.getCount());
    // }
	
	@Override
	public String toString() {
		return "Tag [tag=" + getTag() + ", count=" + getCount() + "]";
	}

}

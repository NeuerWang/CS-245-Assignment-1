package main;

import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.*;

import com.opencsv.CSVReader;

public class MovieTagSearch {
	public ArrayList<Review> records;
	public ArrayList<Count> tags;
	public ArrayList<Count> movies;

	public MovieTagSearch() {
		this.records = new ArrayList<>();
		this.tags = new ArrayList<>();
		this.movies = new ArrayList<>();
	}

	public static void main(String[] args) {

		String filename = args[0];

		MovieTagSearch movietags = new MovieTagSearch();
		System.out.println("Reading file...");

		movietags.readCSV(filename);
		movietags.printInfo();

		Scanner in = new Scanner(System.in);
		String menu = "Search by Tag or Tag Count? (Enter T or C... or EXIT to exit):";

        String input;
		while (true) {
			System.out.println(menu);
			
			input = in.nextLine();
			if (input.toLowerCase().equals("t")) {
				System.out.println("Enter the tag to search for: ");
			    input = in.nextLine();
				String output = movietags.getTagByName(input);
				System.out.println(output);
			} else if (input.toLowerCase().equals("c")) {
				System.out.println("Enter the count to search for: ");
				try {
            		int val = Integer.parseInt(in.nextLine());
            		String res = movietags.getTagByCount(val);
            		System.out.println(res);
        		} catch (NumberFormatException e) {
					System.out.println("That's not right! Lets try again.");
        		}
			} else if (input.toLowerCase().equals("exit")) {
				System.out.println("Bye ...");
				System.exit(0);
			} else {
				System.out.println("That's not right! Lets try again.");
			}
		}
	}

	public void readCSV(String filename) {
		try {
			CSVReader reader = new CSVReader(new FileReader(filename));

			// Skip the first line
			reader.readNext();

			String[] values;
			while ((values = reader.readNext()) != null) {
				Review record = new Review(values[0], values[1], values[2], values[3]);
				records.add(record);
			}
			reader.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public int findCount(ArrayList<Count> tags, String targetTag) {
		// Ensure ArrayList is sorted
		Collections.sort(tags);

		int left = 0;
		int right = tags.size() - 1;

		while (left <= right) {
			int mid = (left + right) / 2;
			int cmp = tags.get(mid).getTag().compareTo(targetTag);

			if (cmp == 0) {  // if the target tag is found at the midpoint
				return mid;  // return the index of the midpoint
			} else if (cmp < 0) {  // if the target tag comes after the tag at the midpoint
				left = mid + 1;  // move the left pointer to the right of the midpoint
			} else {  // if the target tag comes before the tag at the midpoint
				right = mid - 1;  // move the right pointer to the left of the midpoint
			}
		}

		return -1;  // if the target tag is not found, return -1
	}

    public String getTagByName(String tag){
        int idx = findCount(tags, tag);
		if (idx == -1) {
			return "Tag " + tag + " does not exist!";
		}

		int count = tags.get(idx).getCount();
		return "Tag " + tag + " occurred " + count + " times.";

    }
    
    public String getTagByCount(int count){
    	String result = "";
    	for (Count countEntry : tags) {
    		if (countEntry.getCount() == count) {
    			result += "* " + countEntry.getTag() + "\n" ; 
    		}
    	}
    	
    	if (result.equals("")){
    		result = "No tags found with count of " + count;
    	}
    	
    	return result;
    }


	public void getCounts() {
		for (Review review : records) {
			// Process Tag counts
			int resIdx = findCount(tags, review.getTag());
			if (resIdx == -1) {
				tags.add(new Tag(review.getTag()));
			} else {
				tags.get(resIdx).incrementCount();
			}

			resIdx = findCount(movies, review.getMovieID());
			if (resIdx == -1) {
				movies.add(new Movie(review.getMovieID()));
			} else {
				movies.get(resIdx).incrementCount();
			}

		}
	}

	public void printInfo() {
		getCounts();
		System.out.println("-----------------------------------");
		System.out.println("*** Highest 3 movies by count ***");
		Collections.sort(movies, new Comparator<Count>() {
			@Override
			public int compare(Count s1, Count s2) {
				return (int) (s2.getCount() - s1.getCount());
			}
		});

		for (int i = 0; i < 3; i++) {
			System.out.println(movies.get(i));
		}

		System.out.println();

		System.out.println("*** Lowest 3 movies by count ***");
		Collections.sort(movies, new Comparator<Count>() {
			@Override
			public int compare(Count s1, Count s2) {
				return (int) (s1.getCount() - s2.getCount());
			}
		});
		for (int i = 0; i < 3; i++) {
			System.out.println(movies.get(i));
		}

		System.out.println("-----------------------------------");
	}

}

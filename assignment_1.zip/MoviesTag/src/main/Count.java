
package main;

class Count implements Comparable<Count> {
    private String tag;
    private int count;

    public Count(String tag) {
        this.tag = tag;
        this.count = 1;
    }

    public void incrementCount() {
        count++;
    }

    public String getTag() {
        return tag;
    }

    public int getCount() {
        return count;
    }

	@Override
    public int compareTo(Count other) {
        return this.tag.compareTo(other.getTag());
    }

}
## Functional Requirement 1

- Data structures used:
  ArrayList: used to store the Review objects read from the file.

- Algorithm:
  - Create a CSVReader object and pass the filename to its constructor.
  - Call readNext() on the reader object to skip the first line.
  - Create a Review object from the array of strings and add it to the ArrayList.

- Running Time:

  O(n), where n is the number of lines in the file.

  This is because the algorithm reads each line of the file exactly once and performs a constant amount of work for each line.

## Functional Requirement 2

- Data structures used:

  - ArrayList: data structures used to store the Tag and Movie objects.

  - Count: Superclass class representing the count of a particular tag or movie.

  - Tag and Movie: classes that extend the Count class and represent a particular tag or movie.

- Algorithm:

  - Loops through each Review object in the records ArrayList. Call the findCount() method on the tags ArrayList to find the index of the tag associated with the current review. If the tag is not found, create a new Tag object and add it to the tags ArrayList. If the tag is found, increment its count.

- Running Time:
  - O(n log n), where n is the number of reviews in the records ArrayList.

  - The findCount() method has a time complexity of O(log n), because it uses binary search to find the index of the target tag or movie in the sorted ArrayList.

## Functional Requirement 3

- Data Structures Used

  - The getTagByName method uses an ArrayList of Count objects named tags. The getTagByCount method also uses the same tags ArrayList.

- Algorithm Used

  For getTagByName, the method calls the findCount method to check if the provided tag exists in the tags ArrayList. If it exists, the method returns a string containing the name of the tag and the number of times it appears in the reviews. If it does not exist, the method returns a string indicating that the tag was not found.

  For getTagByCount, the method iterates through each Count object in the tags ArrayList and checks if its count matches the provided count argument. If there is a match, the method appends the name of the tag to the result string with a bullet point. If there are no matches, the method returns a string indicating that no tags were found with the specified count.

- Running Time

  - The findCount method used by getTagByName has a worst-case time complexity of O(log n), as it uses binary search The getTagByName method a worst-case time complexity of O(log n).

    - The getTagByCount method iterates through every item in the tags ArrayList, giving it a worst-case time complexity of O(n), where n is the number of items in the tags ArrayList. The method then builds a string containing the names of all tags with the specified count, which has a worst-case time complexity of O(k), where k is the number of matching tags. Therefore, the worst-case time complexity of getTagByCount is O(n+k).


## Dependencies

The provided implementation uses OpenCSV, which is an external library for reading and writing CSV files in Java. To use OpenCSV in your Java project:

1. Add the OpenCSV library to your project's dependencies. You can do this using Maven or Gradle, or by manually adding the JAR file to your project's classpath.
2. Import the necessary classes:
```java
import com.opencsv.CSVReader;
import java.io.FileReader;
import java.io.IOException;
```

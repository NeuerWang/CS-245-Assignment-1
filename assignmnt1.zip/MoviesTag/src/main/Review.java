package main;

public class Review implements Comparable<Review> {
	private String userID;
	private String movieID;
	private String tag;
	private String timestamp;

	public Review(String userID, String movieID, String tag, String timestamp) {
		this.userID = userID;
		this.movieID = movieID;
		this.tag = tag;
		this.timestamp = timestamp;
	}

	public String getUserID() {
		return userID;
	}

	public String getMovieID() {
		return movieID;
	}

	public String getTag() {
		return tag;
	}

	public String getTimestamp() {
		return timestamp;
	}

	@Override
    public int compareTo(Review other) {
        return this.tag.compareTo(other.getTag());
    }

	@Override
	public String toString() {
		return "Review [" + userID + ", " + movieID + ", " + tag + ", " + timestamp + "]";
	}

}
